INKA ADN - PROYECTO ANDROID 0.4

Esta versión mejora el prototipo y lo empaqueta como una aplicación Android.
La aplicación abre el juego desde sus archivos locales; no necesita Chrome ni Internet para jugar una vez instalada.

MEJORAS DE ESTA VERSIÓN:
- Nombre de aplicación: INKA ADN.
- Identificador Android: com.inka.adn.
- Icono propio de ADN.
- Progreso y XP guardados localmente en el dispositivo.
- Opción para reiniciar el progreso desde el diario.
- Botón Atrás de Android integrado con la interfaz del juego.
- Pantalla completa y controles táctiles.

ALCANCE REAL:
- El juego es un prototipo educativo en canvas 2D con perspectiva simulada.
- No es todavía un motor 3D nativo ni un juego 3D de mundo abierto.
- Este ZIP contiene el código fuente Android, NO un APK compilado.
- El APK se genera en GitHub Actions mediante el flujo incluido.

CÓMO GENERAR EL APK DESDE UN CELULAR ANDROID:
1. Descarga y descomprime este ZIP.
2. Entra en https://github.com y crea una cuenta si aún no tienes una.
3. Crea un repositorio nuevo (puede ser privado).
4. Sube todos los archivos y carpetas manteniendo la estructura.
5. Abre la pestaña Actions del repositorio.
6. Selecciona "Build INKA ADN APK" y pulsa "Run workflow".
7. Espera a que el proceso termine correctamente.
8. Abre la ejecución y descarga el artefacto "INKA-ADN-APK".
9. Descomprime el artefacto y encontrarás app-debug.apk.
10. Instálalo en tu Android. Instala únicamente APKs que provengan de tu propia compilación y revisa los permisos que Android solicite.

Para publicar en Google Play se necesitará una compilación de lanzamiento firmada y cumplir las políticas vigentes de Google Play.
